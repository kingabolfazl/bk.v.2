<?php
$db_servername = 'db';
$db_username = 'homestead';
$db_password = 'secret';
$db_database = 'homestead';
?>

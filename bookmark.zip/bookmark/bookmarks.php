<?php
$bookmarks1 = $row['bookmarks'];
require ("./connect.php");
$sql = 'SELECT * FROM folderassign WHERE folder';
$result = $db->query($sql);
if (!$result) {
  die ('Etwas stimmte mit dem Query nicht: '.$db->error);}
  while ($row = $result->fetch_assoc()) {
    echo "<li><a href='admin.php?folder=".$bookmarks1."'><i class='glyphicon glyphicon-folder-close'></i></a><span> ".$bookmarks1."</span></li>";
}?>

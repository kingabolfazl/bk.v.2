<?php
if (isset($_POST['submit2'])) {
	require('./connect.php');
$newfolder = $_POST['newfolder'];

$db->query ('INSERT INTO `folder` (`id`, `name`) VALUES (NULL, "'.$newfolder.'")');
echo "
		<div class='alert alert-success alert-dismissable' id='success-del'>
		<a class='close' data-dismiss='alert' aria-label='close'>&times;</a>
		<strong><i class='glyphicon glyphicon-floppy-saved'></i>  Folder würde Erstellt!</strong>";
				echo "<meta http-equiv='refresh' content='1; URL=index.php'>";

}
?>

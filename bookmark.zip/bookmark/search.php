<?php
$searchcount = 0;
$search = $_GET['search'];
if(!empty($_GET['search'])){
  require("./connect.php");
  $sql = 'SELECT * FROM '.$table.' JOIN `bookmark` WHERE "name" LIKE "'.$search.'"';
  $result = $db->query($sql);
  if (!$result) {
    die ('Etwas stimmte mit dem Query nicht 1: '.$db->error);}
    while ($row = $result->fetch_assoc()) {
      $searchcount ++;}

  echo "<div class='alert alert-success alert-dismissable' id='success-del'>
      <a class='close' data-dismiss='alert' aria-label='close'>&times;</a>
      <strong><i class='glyphicon glyphicon-search'></i> ".$searchcount." gefunden </strong>
  </div>";}

?>
